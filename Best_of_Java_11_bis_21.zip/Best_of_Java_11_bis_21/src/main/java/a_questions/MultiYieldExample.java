package a_questions;

public class MultiYieldExample {

	public static void main(String[] args) {
		multiYield("V2", 50);
		multiYield("V1", 50);
		multiYield("V1", 51);
	}

	private static void multiYield(String version, int age) {
		String result = switch (version) {
		case "V1" -> {
			String internal = switch (age) {
			case 51 -> {
				System.out.println("51");
				yield "51";
			}
			default -> "OTHER";
			};

			yield internal += " LAST";
		}
		case "V2" -> "Version 2";
		default -> throw new IllegalArgumentException("Unexpected value: " + version);
		};

		System.out.println("Result " + result);
	}
}
