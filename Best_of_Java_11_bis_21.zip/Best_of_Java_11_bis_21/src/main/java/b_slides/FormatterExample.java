package b_slides;

public class FormatterExample {
	static String formatterJdk16instanceof(Object obj) {
		String formatted = "unknown";
		if (obj instanceof Integer i) {
			formatted = String.format("int %d", i);
		} else if (obj instanceof Long l) {
			formatted = String.format("long %d", l);
		} else if (obj instanceof Double d) {
			formatted = String.format("double %f", d);
		} else if (obj instanceof String s) {
			formatted = String.format("String %s", s);
		}
		return formatted;
	}

	static String formatterJdk17switch(Object obj) {
		String formatted = switch (obj) {
		case Integer i -> String.format("int %d", i);
		case Long l -> String.format("long %d", l);
		case Double d -> String.format("double %f", d);
		case String s -> String.format("String %s", s);
		default -> "unknown";
		};
		return formatted;
	}

	public static void main(String[] args) {

		System.out.println(formatterJdk16instanceof("Michael"));
		System.out.println(formatterJdk17switch("Michael"));
	}

}