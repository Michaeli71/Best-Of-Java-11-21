package b_slides;

import java.util.Optional;
import java.util.stream.Stream;

/**
 * Beispielprogramm für den Workshop "Java 11 bis 20" / das Buch "Java 21 LTS – die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2023 by Michael Inden 
 */
public class NullableExample 
{	
	public static void main(final String[] args)
    {
    	final Stream<Customer> customerStream1 = Stream.ofNullable(findCustomer());
        System.out.println(customerStream1.count());
        
        final Stream<Customer> customerStream2 = Stream.ofNullable(findCustomer());
        final Optional<Customer> optFirst = customerStream2.findFirst();
        
        optFirst.ifPresentOrElse(System.out::println,
                                 () -> System.out.println("No element"));
    }

	private static Customer findCustomer() 
	{
		/*
		var names = new ArrayList<String>();
		names.add("NUMA");
		names.add(42);
		*/
		return null;
	}
}