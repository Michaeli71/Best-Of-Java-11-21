package b_slides;

import java.util.Date;

/**
 * Beispielprogramm für den Workshop "Java 11 bis 20" / das Buch "Java 21 LTS – die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2023 by Michael Inden 
 */
public class RecordImmutabilityExample
{
    public static void main(String[] args)  
    {
		record DateRange(Date start, Date end) {}
		
		DateRange range1 = new DateRange(new Date(71,1,7), new Date(71,2,27));
		System.out.println(range1);
		
		DateRange range2 = new DateRange(new Date(71,6,7), new Date(71,2,27));
		System.out.println(range2);
    }
}
