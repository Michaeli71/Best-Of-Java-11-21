package b_slides;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

/**
 * Beispielprogramm für den Workshop "Java 11 bis 20" / das Buch "Java 21 LTS – die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2023 by Michael Inden 
 */
public class RecordJSONExample
{
	record MyJsonPerson(
		    @JsonProperty("first_name") String firstName,
		    @JsonProperty("last_name") String lastName,
		    String address,
		    Date birthday,
		    List<String> achievements) {
		}

	// Validierung
	public record ItemAsRecord(
			/*@Positive*/ @JsonProperty("id") int id, 
			/*@NotBlank*/ @JsonProperty("name") String name, 
			/*@Size(max = 5)*/ @JsonProperty("location") String location)
	{}
	
	
    public static void main(String[] args) throws JsonProcessingException
    {
        final ObjectMapper mapper = new ObjectMapper().enable(SerializationFeature.INDENT_OUTPUT);
        
        var person = new Person(
        	    "John",
        	    "Doe",
        	    "USA",
        	    new Date(981291289182L),
        	    List.of("Speaker")
        	);

        System.out.println(mapper.writeValueAsString(person));
    }
}
