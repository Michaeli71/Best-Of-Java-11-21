package b_slides.java18.jep420_switch;

import java.time.DayOfWeek;

/**
 * Beispielprogramm für den Workshop "Java 11 bis 20" / das Buch "Java 21 LTS – die Neuerungen"
 *
 * @author Michael Inden
 *
 * Copyright 2023 by Michael Inden
 */
public class SwitchExample
{
    public static void main(final String[] args)
    {
        int numLetters = 0;

        final DayOfWeek day = DayOfWeek.WEDNESDAY;
        switch (day)
        {
            case MONDAY, FRIDAY, SUNDAY -> numLetters = 6;
            case TUESDAY -> numLetters = 7;
            case THURSDAY, SATURDAY -> numLetters = 8;
            case WEDNESDAY -> numLetters = 9;
            default -> throw new IllegalStateException("Invalid day: " + day);
        }
        System.out.println(numLetters);
    }
}
