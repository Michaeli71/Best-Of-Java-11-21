package b_slides.java18.misc;

import java.time.Duration;
import java.time.temporal.ChronoUnit;

/**
 * Beispielprogramm für den Workshop "Java 11 bis 20" / das Buch "Java 21 LTS – die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2023 by Michael Inden 
 */
public class DurationExample
{
    public static void main(final String[] args)
    {
        System.out.println(Duration.of(20L, ChronoUnit.DAYS).isPositive());
        System.out.println(Duration.of(-12L, ChronoUnit.DAYS).isPositive());
        System.out.println(Duration.of(-12L, ChronoUnit.DAYS).isNegative());
        System.out.println(Duration.of(-12L, ChronoUnit.DAYS).isZero());
    }
}
