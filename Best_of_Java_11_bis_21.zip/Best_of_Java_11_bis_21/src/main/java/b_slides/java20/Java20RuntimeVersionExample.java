package b_slides.java20;

import javax.lang.model.SourceVersion;

/**
 * Beispielprogramm für den Workshop "Java 11 bis 20" / das Buch "Java 21 LTS – die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2023 by Michael Inden 
 */
public class Java20RuntimeVersionExample
{
    public static void main(String[] args)
    {
        System.out.println("Runtime required for this: " + SourceVersion.RELEASE_20.runtimeVersion());
        System.out.println("latest: " + SourceVersion.latest());
        System.out.println("valueOf: " + SourceVersion.valueOf("RELEASE_20"));
    }
}