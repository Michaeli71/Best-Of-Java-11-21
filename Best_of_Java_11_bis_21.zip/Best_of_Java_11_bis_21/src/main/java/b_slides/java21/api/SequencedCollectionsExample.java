package b_slides.java21.api;

import java.util.*;

/**
 * Beispielprogramm für die Workshops "Best of Java 11 - 21" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19"
 *
 * @author Michael Inden
 *         <p>
 *         Copyright 2021/22/23 by Michael Inden
 */
public class SequencedCollectionsExample {
    public static void main(String[] args) {


        sequencedCollectionExample();

        sequenceSetExample();
    }

    public static void sequencedCollectionExample() {
        System.out.println("Processing letterSequence with list");
        SequencedCollection<String> letterSequence = List.of("A", "B", "C", "D", "E");
        System.out.println(letterSequence.getFirst() + " / " + letterSequence.getLast());
        
        // visit elements in reverse order
        System.out.println("Processing letterSequence in reverse order");
        SequencedCollection<String> reversed = letterSequence.reversed();
        reversed.forEach(System.out::print);
        System.out.println();
        System.out.println("reverse order stream skip 3");
        reversed.stream().skip(3).forEach(System.out::print);
        System.out.println();
        System.out.println(reversed.getFirst() + " / " + reversed.getLast());
        System.out.println();


        SequencedCollection<String> oneElement = new ArrayList<>(List.of("A"));
        System.out.println(oneElement.getFirst() == oneElement.getLast());
        oneElement.addLast("Z");
        System.out.println(oneElement);

        SequencedCollection<String> noElement = List.of();
        noElement.getFirst();

    }

    public static void sequenceSetExample() {
        // Plain Sets do not have encounter order ... run multiple time to see variation
        System.out.println("Processing set of letters A-D");
        Set.of("A", "B", "C", "D").forEach(System.out::print);
        System.out.println();
        System.out.println("Processing set of letters A-I");
        Set.of("A", "B", "C", "D", "E", "F", "G", "H", "I").forEach(System.out::print);
        System.out.println();

        // TreeSet has order
        System.out.println("Processing letterSequence with tree set");
        SequencedSet<String> sortedLetters = new TreeSet<>((Set.of("C", "B", "A", "D")));
        System.out.println(sortedLetters.getFirst() + " / " + sortedLetters.getLast());
        sortedLetters.reversed().forEach(System.out::print);
        System.out.println();
    }
}