package b_slides.java21.preview.syntax;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.text.MessageFormat;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import static java.util.FormatProcessor.FMT;

/**
 * Beispielprogramm für die Workshops "Best of Java 11 - 21" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/22/23 by Michael Inden
 */
public class JEP430_StringTemplates {
    public static void main(String[] args) {

        oldStyle();
        newStyle();
        newStyleJsonHtml();
        newCalculations();
        notAlwaysBestChoice();

        alternativeStringProcessors();
    }


    static void oldStyle() {
        int x = 47, y = 11;

        // OLD STYLE
        String result = "Calculation: " + x + " plus " + y + " equals " + (x + y);
        System.out.println(result);

        String resultSB = new StringBuilder().
                append("Calculation: ").append(x).append(" plus ").
                append(y).append(" equals ").append(x + y).toString();
        System.out.println(resultSB);

        String resultF1 = String.format("Calculation: %d plus %d equals %d",
                x, y, x + y);
        System.out.println(resultF1);

        String resultF2 = "Calculation: %d plus %d equals %d".formatted(x, y,
                x + y);
        System.out.println(resultF2);

        var messageFormat = new MessageFormat("Calculation: {0} plus {1} equals {2}");
        System.out.println(messageFormat.format(new Object[]{x, y, x + y}));
    }

    static void newStyle() {
        int x = 47, y = 11;

        System.out.println(STR. "Calculation: \{ x } plus \{ y } equals \{ x + y }" );

        String firstName = "Michael";
        String lastName = "Inden";
        String firstLastName = STR."\{ firstName } \{ lastName }" ;
        String lastFirstName = STR. "\{ lastName }, \{ firstName }" ;
        System.out.println(firstLastName);
        System.out.println(lastFirstName);

        Path filePath = Path.of("example.txt");
        String infoOld = "The file " + filePath + " " +
                (filePath.toFile().exists() ? "does" : "does not" + " exist");
        String infoNew = STR. "The file \{ filePath } " +
                STR. "\{ filePath.toFile().exists() ? "does " : "does not " }" +
                "exist";
        ;
    }

    static void newStyleJsonHtml() {
        int statusCode = 201;
        var msg = "CREATED";

        String json = STR. """
                 {
                   "statusCode": \{ statusCode },
                   "msg": "\{ msg }"
                }""" ;
        System.out.println(json);

        String title = "My First Web Page";
        String text = "My Hobbies:";
        var hobbies = List.of("Cycling", "Hiking", "Shopping");
        String html = STR. """
                <html>
                    <head><title>\{ title }</title></head>
                    <body>
                        <p>\{ text }</p>
                        <ul>
                            <li>\{ hobbies.get(0) }</li>
                            <li>\{ hobbies.get(1) }</li>
                            <li>\{ hobbies.get(2) }</li>
                        </ul>
                    </body>
                </html>""" ;
        System.out.println(html);
        try {
            Files.writeString(Path.of("MFWP.html"), html);
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    static void newCalculations() {

        int x = 10, y = 20;
        String calculation = STR. "\{ x } + \{ y } = \{ x + y }" ;
        System.out.println(calculation);

        int index = 0;
        String modifiedIndex = STR. "\{ index++ }, \{ index++ }, \{ index++ }, \{ index++ }" ;
        System.out.println(modifiedIndex);

        String currentTime = STR. "Current time: \{ DateTimeFormatter.ofPattern("HH:mm").format(LocalTime.now()) }" ;

        System.out.println(currentTime);
    }

    static void notAlwaysBestChoice() {
        var sophiesBirthday = LocalDateTime.parse("2020-11-23T09:02");

        var infoSophie = STR. "Sophie was born on \{
                DateTimeFormatter.ofPattern("dd.MM.yyyy").format(sophiesBirthday) } at \{
                DateTimeFormatter.ofPattern("HH:mm").format(sophiesBirthday) }" ;
        System.out.println(infoSophie);

        System.out.println("Sophie was born on %s at %s".formatted(
                DateTimeFormatter.ofPattern("dd.MM.yyyy").format(sophiesBirthday),
                DateTimeFormatter.ofPattern("HH:mm").format(sophiesBirthday)));
    }

    private static void alternativeStringProcessors() {
        int x = 47;
        int y = 11;

        String calculation1 = FMT. "%6d\{ x } + %6d\{ y } = %6d\{ x + y }" ;
        System.out.println("fmt calculation 1: " + calculation1);

        float base = 3.0f;
        float addon = 0.1415f;

        String calculation2 = FMT. "%2.4f\{ base } + %2.4f\{ addon }" +
                FMT. " = %2.4f\{ base + addon }" ;
        System.out.println("fmt calculation 2: " + calculation2);

        String calculation3 = FMT. "Math.PI * 1.000 = %4.6f\{ Math.PI * 1000 }" ;
        System.out.println("fmt calculation 3: " + calculation3);
    }
}
