package b_slides.java21.syntax.jep441_switch_pattern_matching;

/**
 * Beispielprogramm für den Workshop "Java 11 bis 20" / das Buch "Java 21 LTS – die Neuerungen"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2023 by Michael Inden
 */
public class SwitchMultiPatternExample 
{
    public static void main(final String[] args) 
    {
        multiMatch("Python");
        multiMatch(null);
    }

    static void multiMatch(Object obj) {
        switch (obj) {
            case null -> System.out.println("null");
            case String str when str.length() > 5 -> System.out.println(str.strip());
            case String str -> System.out.println(str.toLowerCase());
            case Integer i -> System.out.println(i * i);
            default -> {
            }
        }
    }
}