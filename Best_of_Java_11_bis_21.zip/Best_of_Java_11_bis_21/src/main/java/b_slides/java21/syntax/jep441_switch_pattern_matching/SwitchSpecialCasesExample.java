package b_slides.java21.syntax.jep441_switch_pattern_matching;

/**
 * Beispielprogramm für den Workshop "Java 11 bis 20" / das Buch "Java 21 LTS – die Neuerungen"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2023 by Michael Inden
 */
public class SwitchSpecialCasesExample
{
    interface Shape {}

    record Rectangle() implements Shape {}
    record Triangle()  implements Shape { int calculateArea() { return 7271; } }

    static void testTriangleAndString(Object obj)
    {
        switch (obj)
        {
            case Triangle t when t.calculateArea() > 7000 ->
                    System.out.println("Large triangle");
            case String str when str.startsWith("INFO") ->
                    System.out.println("just an info");
            default ->
                    System.out.println("Something else: " + obj);
        }
    }

    static void testTriangleAndString2(Object obj)
    {
        switch (obj)
        {
            case Triangle t when t.calculateArea() > 7000 ->
                System.out.println("Large triangle");
            case String str when str.startsWith("INFO") && str.contains("SPECIAL") ->
                System.out.println("a very special info");
            case String str when str.startsWith("INFO") ->
                System.out.println("just an info");
            // not detected ...
            case String str when str.startsWith("INFO") && str.contains("SPECIAL") ->
                System.out.println("a very special info");
            default ->
               System.out.println("Something else: " + obj);
        }
    }

    public static void main(String[] args)
    {
        testTriangleAndString(new Triangle());
        testTriangleAndString("INFO: switch and when");
        testTriangleAndString("INFO: switch and SPECIAL");
        testTriangleAndString2("INFO: switch and SPECIAL");
        testTriangleAndString("Michael");
    }
}
