package exercises.part6;

import java.time.Duration;
import java.util.concurrent.Executors;
import java.util.stream.IntStream;

/**
 * Sample program for the workshop "Best of Java 11 to 21" / the book "Java 21 LTS - the innovations"
 * 
 * @author Michael Inden
 * 
 * Copyright 2023 by Michael Inden
 */
public class Exercise03_ThreadingExample {
    public static void main(String[] args) {
        try (var executor = Executors.newFixedThreadPool(50)) {
            IntStream.range(0, 1_000).forEach(i -> {
                executor.submit(() -> {
                    Thread.sleep(Duration.ofSeconds(1));

                    System.out.println("Task " + i + " finished!");
                    return i;
                });
            });
        }

        System.out.println("FINISHED");
    }
}
