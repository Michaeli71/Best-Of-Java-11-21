package solutions.part1;

import java.util.function.Function;
import java.util.stream.Stream;

/**
 * Beispielprogramm für den Workshop "Java 11 bis 20" / das Buch "Java 21 LTS – die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2023 by Michael Inden
 */
public class Exercise05a_Strings 
{
	public static void main(String[] args) 
	{
		Function<Integer, String> mapper = num -> ("" + num).repeat(num);
		
		Stream.of(2,4,7,3,1,9,5).map(mapper).
		                         forEach(System.out::println);
		
        var coffeePot = """ 
                        _.._..,_,_
                        (          )
                         ]~,"-.-~~[
                       .=])' (;  ([
                       | ]:: '    [
                       '=]): .)  ([
                         |:: '    |
                          ~~----~~""";
        System.out.println(coffeePot);
        
	}	
}