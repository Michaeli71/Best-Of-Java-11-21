package solutions.part6;

import java.time.Duration;
import java.util.concurrent.Executors;
import java.util.stream.IntStream;

/**
 * Beispielprogramm für den Workshop "Java 11 bis 18" / das Buch "Java – die
 * Neuerungen in Java 17 LTS und 18"
 *
 * @author Michael Inden
 *
 *         Copyright 2021/2022 by Michael Inden
 */
public class Exercise03_ThreadingExample {
    public static void main(String[] args) {
        try (var executor = Executors.newVirtualThreadPerTaskExecutor()) {
            IntStream.range(0, 1_000).forEach(i -> {
                executor.submit(() -> {
                    Thread.sleep(Duration.ofSeconds(1));

                    boolean isVirtual = Thread.currentThread().isVirtual();
                    System.out.println("Task " + i + " finished! virtual = " + isVirtual);
                    return i;
                });
            });
        }

        System.out.println("FINISHED");
    }
}
