package solutions.part6;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import jdk.incubator.concurrent.StructuredTaskScope;

/**
 * Beispielprogramm für den Workshop "Java 11 bis 18" / das Buch "Java – die
 * Neuerungen in Java 17 LTS und 18"
 *
 * @author Michael Inden
 *
 *         Copyright 2021/2022 by Michael Inden
 */
public class Exercise04_ConcurrencyExample {

    public static void main(String[] args) throws ExecutionException, InterruptedException {

        executeTasks(false);

        executeTasks(true);
    }

    private static void executeTasks(boolean forceFailure) throws InterruptedException, ExecutionException {

        try (var scope = new StructuredTaskScope.ShutdownOnFailure()) {

            Future<String> task1 = scope.fork(() -> {
                return "1";
            });
            Future<String> task2 = scope.fork(() -> {
                if (forceFailure)
                    throw new IllegalStateException("FORCED BUG");

                return "2";
            });
            Future<String> task3 = scope.fork(() -> {
                return "3";
            });

            scope.join();
            scope.throwIfFailed();

            System.out.println(task1.get());
            System.out.println(task2.get());
            System.out.println(task3.get());
        }
    }
}
