package solutions;

import java.util.ArrayList;
import java.util.List;

/**
 * Beispielprogramm für die Workshops "Best of Java 11 - 21" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19"
 *
 * @author Michael Inden
 *         <p>
 *         Copyright 2021/22/23 by Michael Inden
 */
public class Ex05_SequencedCollections {
    public static void main(String[] args) {
        List<Integer> primeNumbers = new ArrayList<>();
        primeNumbers.add(3); // [3]
        primeNumbers.addFirst(2); // [2, 3]
        primeNumbers.addAll(List.of(5, 7, 11)); // [2, 3, 5, 7, 11]
        primeNumbers.addLast(13); // [2, 3, 5, 7, 11, 13]

        System.out.println(primeNumbers); // [2, 3, 5, 7, 11, 13]
        System.out.println(primeNumbers.getFirst()); // 2
        System.out.println(primeNumbers.getLast()); // 13
        System.out.println(primeNumbers.reversed()); // [13, 11, 7, 5, 3, 2]

        primeNumbers.addLast(17);
        System.out.println(primeNumbers); // [2, 3, 5, 7, 11, 13, 17]
        System.out.println(primeNumbers.reversed()); // [17, 13, 11, 7, 5, 3, 2]
    }
}
