package solutions;

import java.util.LinkedHashSet;
import java.util.SequencedSet;

/**
 * Beispielprogramm für die Workshops "Best of Java 11 - 21" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19"
 *
 * @author Michael Inden
 *         <p>
 *         Copyright 2021/22/23 by Michael Inden
 */
public class Ex05_SequencedSet {
    public static void main(String[] args) {
        SequencedSet<String> numbers = new LinkedHashSet<>();
        numbers.add("B"); // [B]
        numbers.addFirst("A"); // [A, B]
        numbers.addLast("C"); // [A, B, C]
        System.out.println(numbers);

        System.out.println(numbers.getFirst()); // A
        System.out.println(numbers.getLast()); // C
        System.out.println(numbers.reversed()); // [C, B, A]
    }
}
