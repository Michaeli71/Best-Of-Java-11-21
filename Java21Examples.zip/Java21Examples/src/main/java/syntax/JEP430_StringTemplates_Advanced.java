package syntax;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import static java.lang.StringTemplate.STR;
import static java.util.FormatProcessor.FMT;

/**
 * Beispielprogramm für die Workshops "Best of Java 11 - 21" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19"
 *
 * @author Michael Inden
 *         <p>
 *         Copyright 2021/22/23 by Michael Inden
 */
public class JEP430_StringTemplates_Advanced {
    public static void main(final String[] args) {
        String name = "Michael";
        int age = 52;
        System.out.println(STR."Hello \{name}. You are \{age} years old.");

        var myProc = new MyProcessor();
        System.out.println(myProc."Hello \{name}. You are \{age} years old.");
    }

static class MyProcessor implements StringTemplate.Processor<String, IllegalArgumentException> {
    @Override
    public String process(StringTemplate stringTemplate) throws IllegalArgumentException {
        System.out.println("\n-- process() --");
        System.out.println("info fragments:" + stringTemplate.fragments());
        System.out.println("info values: " + stringTemplate.values());
        System.out.println("info interpolate: " + stringTemplate.interpolate());
        System.out.println();

        var adjustedValues = stringTemplate.values().stream().map(str -> ">>" + str + "<<").toList();

        return StringTemplate.interpolate(stringTemplate.fragments(), adjustedValues);
    }
}
}
